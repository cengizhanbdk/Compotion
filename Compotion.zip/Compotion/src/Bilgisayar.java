public class Bilgisayar {
    private Monitor monitor1;
    private Kasa kasa1;
    private Anakart anakart1;


    public Bilgisayar(Monitor monitor1, Kasa kasa1, Anakart anakart1) {
        this.monitor1 = monitor1;
        this.kasa1 = kasa1;
        this.anakart1 = anakart1;
    }


    public Monitor getMonitor1() {
        return monitor1;
    }

    public void setMonitor1(Monitor monitor1) {
        this.monitor1 = monitor1;
    }

    public Kasa getKasa1() {
        return kasa1;
    }

    public void setKasa1(Kasa kasa1) {
        this.kasa1 = kasa1;
    }

    public Anakart getAnakart1() {
        return anakart1;
    }

    public void setAnakart1(Anakart anakart1) {
        this.anakart1 = anakart1;
    }
}
