public class Monitor {
    private String model;
    private String uretivi;
    private String boyut;
    private Resulution resulution1;

    public Monitor(String model,String uretivi,String boyut,Resulution resulution1) {

        this.model=model;
        this.boyut=boyut;
        this.uretivi=uretivi;
        this.resulution1=resulution1;

    }
    public void Monitoru_kapat(){
        System.out.println("Monitor Kapatliyor");


    }


    public String getBoyut() {
        return boyut;
    }

    public void setBoyut(String boyut) {
        this.boyut = boyut;
    }

    public Resulution getResulution1() {
        return resulution1;
    }

    public void setResulution1(Resulution resulution1) {
        this.resulution1 = resulution1;
    }

    public String getUretivi() {
        return uretivi;
    }

    public void setUretivi(String uretivi) {
        this.uretivi = uretivi;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
