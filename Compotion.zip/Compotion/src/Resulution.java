public class Resulution {
    private int en;
    private int boy;


    public Resulution(int en,int boy) {
        this.boy=boy;
        this.en=en;
    }

    public int getBoy() {
        return boy;
    }

    public void setBoy(int boy) {
        this.boy = boy;
    }

    public int getEn() {
        return en;
    }

    public void setEn(int en) {
        this.en = en;
    }
}
