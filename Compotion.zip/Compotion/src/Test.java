public class Test {

    public static void main(String[] args){

        Resulution resulution1=new Resulution(1900,2000);
        Monitor monitor1=new Monitor("asd","asus","34",resulution1);
        Kasa kasa1=new Kasa("cengizhan als","şasd","şas");
        Anakart anakart=new Anakart("aşs","slş",2,"ss");
        Bilgisayar pc =new Bilgisayar(monitor1,kasa1,anakart);

        pc.getKasa1().bilgisayari_ac();
        pc.getMonitor1().Monitoru_kapat();
        pc.getAnakart1().isletim_sistemi_yukle(" ubuntu");



    }






}
